package apc.entjava.photogallery.businesslogic;

import apc.entjava.photogallery.model.Item;
import apc.entjava.photogallery.model.User;

/**
 * Created by Centi on 16/12/2016.
 */
public interface ItemService {
    void addItem(Item newItem);

}
