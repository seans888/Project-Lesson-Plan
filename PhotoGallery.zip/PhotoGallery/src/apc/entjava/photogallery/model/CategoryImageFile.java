package apc.entjava.photogallery.model;

/**
 * Created by jacobcat on 12/2/2016.
 */
public class CategoryImageFile extends File {
}
